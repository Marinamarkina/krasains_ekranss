﻿
namespace balts_melns
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.buttonBalts = new System.Windows.Forms.Button();
            this.buttonMelns = new System.Windows.Forms.Button();
            this.buttonZals = new System.Windows.Forms.Button();
            this.buttonZils = new System.Windows.Forms.Button();
            this.buttonSarkans = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonViolets = new System.Windows.Forms.Button();
            this.buttonRoza = new System.Windows.Forms.Button();
            this.buttonBruns = new System.Windows.Forms.Button();
            this.buttonDzeltens = new System.Windows.Forms.Button();
            this.buttonPeleks = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label1.Location = new System.Drawing.Point(98, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(375, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Uzspied, lai mainitu fonta krasu";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // buttonBalts
            // 
            this.buttonBalts.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBalts.Location = new System.Drawing.Point(52, 105);
            this.buttonBalts.Name = "buttonBalts";
            this.buttonBalts.Size = new System.Drawing.Size(108, 59);
            this.buttonBalts.TabIndex = 1;
            this.buttonBalts.Text = "balts";
            this.buttonBalts.UseVisualStyleBackColor = true;
            this.buttonBalts.Click += new System.EventHandler(this.buttonBalts_Click);
            // 
            // buttonMelns
            // 
            this.buttonMelns.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMelns.Location = new System.Drawing.Point(208, 105);
            this.buttonMelns.Name = "buttonMelns";
            this.buttonMelns.Size = new System.Drawing.Size(123, 59);
            this.buttonMelns.TabIndex = 2;
            this.buttonMelns.Text = "melns";
            this.buttonMelns.UseVisualStyleBackColor = true;
            this.buttonMelns.Click += new System.EventHandler(this.buttonMelns_Click);
            // 
            // buttonZals
            // 
            this.buttonZals.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonZals.Location = new System.Drawing.Point(371, 105);
            this.buttonZals.Name = "buttonZals";
            this.buttonZals.Size = new System.Drawing.Size(123, 59);
            this.buttonZals.TabIndex = 3;
            this.buttonZals.Text = "zaļš";
            this.buttonZals.UseVisualStyleBackColor = true;
            this.buttonZals.Click += new System.EventHandler(this.buttonZals_Click);
            // 
            // buttonZils
            // 
            this.buttonZils.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonZils.Location = new System.Drawing.Point(121, 183);
            this.buttonZils.Name = "buttonZils";
            this.buttonZils.Size = new System.Drawing.Size(123, 59);
            this.buttonZils.TabIndex = 4;
            this.buttonZils.Text = "zils";
            this.buttonZils.UseVisualStyleBackColor = true;
            this.buttonZils.Click += new System.EventHandler(this.buttonZils_Click);
            // 
            // buttonSarkans
            // 
            this.buttonSarkans.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSarkans.Location = new System.Drawing.Point(291, 183);
            this.buttonSarkans.Name = "buttonSarkans";
            this.buttonSarkans.Size = new System.Drawing.Size(151, 59);
            this.buttonSarkans.TabIndex = 5;
            this.buttonSarkans.Text = "sarkans";
            this.buttonSarkans.UseVisualStyleBackColor = true;
            this.buttonSarkans.Click += new System.EventHandler(this.buttonSarkans_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label2.Location = new System.Drawing.Point(98, 269);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(387, 29);
            this.label2.TabIndex = 6;
            this.label2.Text = "Uzspied, lai mainitu teksta krasu";
            // 
            // buttonViolets
            // 
            this.buttonViolets.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonViolets.Location = new System.Drawing.Point(52, 311);
            this.buttonViolets.Name = "buttonViolets";
            this.buttonViolets.Size = new System.Drawing.Size(125, 59);
            this.buttonViolets.TabIndex = 7;
            this.buttonViolets.Text = "violets";
            this.buttonViolets.UseVisualStyleBackColor = true;
            this.buttonViolets.Click += new System.EventHandler(this.buttonViolets_Click);
            // 
            // buttonRoza
            // 
            this.buttonRoza.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRoza.Location = new System.Drawing.Point(208, 311);
            this.buttonRoza.Name = "buttonRoza";
            this.buttonRoza.Size = new System.Drawing.Size(108, 59);
            this.buttonRoza.TabIndex = 8;
            this.buttonRoza.Text = "roza";
            this.buttonRoza.UseVisualStyleBackColor = true;
            this.buttonRoza.Click += new System.EventHandler(this.buttonRoza_Click);
            // 
            // buttonBruns
            // 
            this.buttonBruns.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBruns.Location = new System.Drawing.Point(351, 311);
            this.buttonBruns.Name = "buttonBruns";
            this.buttonBruns.Size = new System.Drawing.Size(122, 59);
            this.buttonBruns.TabIndex = 9;
            this.buttonBruns.Text = "brūns";
            this.buttonBruns.UseVisualStyleBackColor = true;
            this.buttonBruns.Click += new System.EventHandler(this.buttonBruns_Click);
            // 
            // buttonDzeltens
            // 
            this.buttonDzeltens.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDzeltens.Location = new System.Drawing.Point(121, 379);
            this.buttonDzeltens.Name = "buttonDzeltens";
            this.buttonDzeltens.Size = new System.Drawing.Size(155, 59);
            this.buttonDzeltens.TabIndex = 10;
            this.buttonDzeltens.Text = "dzeltens";
            this.buttonDzeltens.UseVisualStyleBackColor = true;
            this.buttonDzeltens.Click += new System.EventHandler(this.buttonDzeltens_Click);
            // 
            // buttonPeleks
            // 
            this.buttonPeleks.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPeleks.Location = new System.Drawing.Point(319, 379);
            this.buttonPeleks.Name = "buttonPeleks";
            this.buttonPeleks.Size = new System.Drawing.Size(123, 59);
            this.buttonPeleks.TabIndex = 11;
            this.buttonPeleks.Text = "peleks";
            this.buttonPeleks.UseVisualStyleBackColor = true;
            this.buttonPeleks.Click += new System.EventHandler(this.buttonPeleks_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(550, 450);
            this.Controls.Add(this.buttonPeleks);
            this.Controls.Add(this.buttonDzeltens);
            this.Controls.Add(this.buttonBruns);
            this.Controls.Add(this.buttonRoza);
            this.Controls.Add(this.buttonViolets);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonSarkans);
            this.Controls.Add(this.buttonZils);
            this.Controls.Add(this.buttonZals);
            this.Controls.Add(this.buttonMelns);
            this.Controls.Add(this.buttonBalts);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "la";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonBalts;
        private System.Windows.Forms.Button buttonMelns;
        private System.Windows.Forms.Button buttonZals;
        private System.Windows.Forms.Button buttonZils;
        private System.Windows.Forms.Button buttonSarkans;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonViolets;
        private System.Windows.Forms.Button buttonRoza;
        private System.Windows.Forms.Button buttonBruns;
        private System.Windows.Forms.Button buttonDzeltens;
        private System.Windows.Forms.Button buttonPeleks;
    }
}

